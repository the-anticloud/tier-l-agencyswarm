# OWASP findings, cited

**Project:** `L_AGENCYSWARM`  
**Tier:** TIER_4_INFERENCE_AGENTS  
**Identity:** Upstream `crewAIInc/crewAI` @ `a0d16dde6ecf` (MIT)

## Purpose

Third-party and published results, as-is.

## This project

| Fact | Value |
| --- | --- |
| Upstream | `crewAIInc/crewAI` |
| Commit | `a0d16dde6ecf205211f639d613eceef0cc42ae20` |
| Upstream licence | MIT |
| Licence class | permissive |
| Clone size | 399.03 MB |
| Ledger | 0 blocks, chain verified |
| Current TRL | NOT YET MEASURED |
| Post-optimisation TRL | NOT YET MEASURED |
| II budget cap | 1000.0 IIU |
| Verified upstream edits | 1 |

## Known gaps

Everything above is read from an artifact. Where this document says
`NOT YET MEASURED`, the value has not been measured for `L_AGENCYSWARM` as of
generation. Filling those in requires a run or a decision, not editing.
